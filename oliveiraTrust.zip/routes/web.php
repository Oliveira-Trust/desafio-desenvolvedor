<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

/*
 * ROTAS CLIENTES
 */
Route::get('/cliente', 'ClienteController@index');

Route::get('/cliente/novo', 'ClienteController@create');
Route::post('/cliente/store', 'ClienteController@store');

Route::get('/cliente/{name}', 'ClienteController@show');

Route::get('/cliente/editar/{name}', 'ClienteController@edit');
Route::put('/cliente/update/{name}', 'ClienteController@update');

Route::get('/cliente/remover/{name}', 'ClienteController@destroy');

/*
 * ROTAS PRODUTOS
 */
Route::get('/produto', 'ProdutoController@index');

Route::get('/produto/novo', 'ProdutoController@create');
Route::post('/produto/store', 'ProdutoController@store');

Route::get('/produto/{name}', 'ProdutoController@show');

Route::get('/produto/editar/{name}', 'ProdutoController@edit');
Route::put('/produto/update/{name}', 'ProdutoController@update');

Route::get('/produto/remover/{name}', 'ProdutoController@destroy');

/*
 * ROTAS PEDIDOS
 */
Route::get('/pedido', 'PedidoController@index');

Route::get('/pedido/novo', 'PedidoController@create');
Route::post('/pedido/store', 'PedidoController@store');

Route::get('/pedido/{name}', 'PedidoController@show');

Route::get('/pedido/editar/{name}', 'PedidoController@edit');
Route::put('/pedido/update/{name}', 'PedidoController@update');

Route::get('/pedido/remover/{name}', 'PedidoController@destroy');

/*
 * ROTAS AUTENTICAÇÃO
 */
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/admin', 'AuthController@dashboard')->name('admin');
Route::get('/admin/login', 'AuthController@showLoginForm')->name('admin.login');
Route::post('/admin/login/do', 'AuthController@login')->name('admin.login.do');
Route::get('/admin/logout', 'AuthController@logout')->name('admin.logout');

