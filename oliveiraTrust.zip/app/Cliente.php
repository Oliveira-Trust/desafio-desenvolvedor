<?php

namespace OliveiraTrust;

use Illuminate\Database\Eloquent\Model;

class Cliente extends Model
{
    protected $table = 'clientes';

    protected $fillable = ['title', 'name', 'document', 'phone', 'address'];

    public $timestamps = false;
}
