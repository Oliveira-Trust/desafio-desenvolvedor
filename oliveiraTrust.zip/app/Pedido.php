<?php

namespace OliveiraTrust;

use Illuminate\Database\Eloquent\Model;

class Pedido extends Model
{
    protected $table = 'pedidos';

    protected $fillable = ['name', 'cliente', 'produto', 'status'];

    public $timestamps = false;
}
