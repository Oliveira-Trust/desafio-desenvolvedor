<?php

namespace OliveiraTrust;

use Illuminate\Database\Eloquent\Model;

class Produto extends Model
{
    protected $table = 'produtos';

    protected $fillable = ['title', 'name', 'description', 'price'];

    public $timestamps = false;
}
