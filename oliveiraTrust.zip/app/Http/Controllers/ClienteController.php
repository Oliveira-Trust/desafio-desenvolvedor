<?php

namespace OliveiraTrust\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use OliveiraTrust\Cliente;

class ClienteController extends Controller
{
    /*
     * Mostra Clientes Na Index
     */
    public function index()
    {
        $clientes = Cliente::all();

        return view('cliente.index')->with('clientes', $clientes);
    }

    /*
     * Mostra Cliente Na Single
     */
    public function show($name)
    {
        $cliente = Cliente::where('name', $name)->get();

        if (!empty($cliente)) {
            return view('cliente.show')->with('clientes', $cliente);
        } else {
            return redirect()->action('ClienteController@index');
        }
    }

    /*
     * Redireciona Para Criação do Cliente
     */
    public function create()
    {
        return view('cliente.create');
    }

    /*
     * Cadastra Cliente
     */
    public function store(Request $request)
    {
        $clienteSlug = $this->setName($request->title);

        $cliente = [
            'title' => $request->title,
            'name' => $clienteSlug,
            'document' => $request->document,
            'phone' => $request->phone,
            'address' => $request->address
        ];

        Cliente::create($cliente);

        return redirect()->action('ClienteController@index');
    }

    /*
     * Recupera Dados do Cliente Para Atualização
     */
    public function edit($name)
    {
        $cliente = Cliente::where('name', $name)->get();

        if (!empty($cliente)) {
            return view('cliente.edit')->with('cliente', $cliente);
        } else {
            return redirect()->action('ClienteController@index');
        }
    }

    /*
     * Edita Cliente
     */
    public function update(Request $request, $id)
    {
        $clienteSlug = $this->setName($request->title);

        $cliente = Cliente::find($id);

        $cliente->title = $request->title;
        $cliente->name = $clienteSlug;
        $cliente->document = $request->document;
        $cliente->phone = $request->phone;
        $cliente->address = $request->address;

        $cliente->save();

        return redirect()->action('ClienteController@index');
    }

    /*
     * Deleta Cliente
     */
    public function destroy($name)
    {
        $cliente = Cliente::where('name', $name)->get();

        if(!empty($cliente)){
            DB::delete("DELETE FROM clientes WHERE name = ?", [$name]);
        }

        return redirect()->action('ClienteController@index');
    }

    /*
     * Faz Leitura dos Clientes
     */
    private function setName($citle)
    {
        $clienteSlug = str_slug($citle);

        $clientes = DB::select("SELECT * FROM clientes");
        $cliente = Cliente::all();

        $c = 0;
        foreach ($clientes as $cliente) {
            if (str_slug($cliente->title) === $clienteSlug) {
                $c++;
            }
        }

        if ($c > 0) {
            $clienteSlug = $clienteSlug . '-' . $c;
        }

        return $clienteSlug;
    }
}
