<?php

namespace OliveiraTrust\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use OliveiraTrust\Produto;

class ProdutoController extends Controller
{
    /*
     * Mostra Produtos Na Index
     */
    public function index()
    {
        $produtos = Produto::all();

        return view('produto.index')->with('produtos', $produtos);
    }

    /*
     * Mostra Produto Na Single
     */
    public function show($name)
    {
        $produto = Produto::where('name', $name)->get();

        if (!empty($produto)) {
            return view('produto.show')->with('produto', $produto);
        } else {
            return redirect()->action('ProdutoController@index');
        }
    }

    /*
     * Redireciona Para Criação do Produto
     */
    public function create()
    {
        return view('produto.create');
    }

    /*
     * Cadastra Produto
     */
    public function store(Request $request)
    {
        $produtoSlug = $this->setName($request->title);

        $produto = [
            'title' => $request->title,
            'name' => $produtoSlug,
            'description' => $request->description,
            'price' => $request->price
        ];

        Produto::create($produto);

        return redirect()->action('ProdutoController@index');
    }

    /*
     * Recupera Dados do Produto Para Atualização
     */
    public function edit($name)
    {
        $produto = Produto::where('name', $name)->get();

        if (!empty($produto)) {
            return view('produto.edit')->with('produto', $produto);
        } else {
            return redirect()->action('ProdutoController@index');
        }
    }

    /*
     * Edita Produto
     */
    public function update(Request $request, $id)
    {
        $produtoSlug = $this->setName($request->title);

        $produto = Produto::find($id);

        $produto->title = $request->title;
        $produto->name = $produtoSlug;
        $produto->description = $request->description;
        $produto->price = $request->price;

        $produto->save();

        return redirect()->action('ProdutoController@index');
    }

    /*
     * Deleta Produto
     */
    public function destroy($name)
    {
        $produto = Produto::where('name', $name)->get();

        if (!empty($produto)) {
            DB::delete("DELETE FROM produtos WHERE name = ?", [$name]);
        }

        return redirect()->action('ProdutoController@index');
    }

    /*
     * Faz Leitura dos Produtos
     */
    private function setName($title)
    {
        $produtoSlug = str_slug($title);

        $produtos = DB::select("SELECT * FROM produtos");
        $produto = Produto::all();

        $p = 0;
        foreach ($produtos as $produto) {
            if (str_slug($produto->title) === $produtoSlug) {
                $p++;
            }
        }

        if ($p > 0) {
            $produtoSlug = $produtoSlug . '-' . $p;
        }

        return $produtoSlug;
    }
}
