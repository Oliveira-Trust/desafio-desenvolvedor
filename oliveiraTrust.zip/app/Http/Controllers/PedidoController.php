<?php

namespace OliveiraTrust\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use OliveiraTrust\Pedido;

class PedidoController extends Controller
{
    /*
     * Mostra Pedidos Na Index
     */
    public function index()
    {
        $pedidos = Pedido::all();

        return view('pedido.index')->with('pedidos', $pedidos);
    }

    /*
     * Mostra Pedido Na Single
     */
    public function show($id)
    {
        $pedido = Pedido::where('id', $id)->get();

        if (!empty($pedido)) {
            return view('pedido.show')->with('pedido', $pedido);
        } else {
            return redirect()->action('PedidoController@index');
        }
    }

    /*
     * Redireciona Para Criação do Pedido
     */
    public function create()
    {
        return view('pedido.create');
    }

    /*
     * Cadastra Pedido
     */
    public function store(Request $request)
    {
        $pedido = [
            'cliente' => $request->cliente,
            'produto' => $request->produto,
            'status' => $request->status
        ];

        Pedido::create($pedido);

        return redirect()->action('PedidoController@index');
    }

    /*
     * Recupera Dados do Pedido Para Atualização
     */
    public function edit($id)
    {
        $pedido = Pedido::where('id', $id)->get();

        if (!empty($pedido)) {
            return view('pedido.edit')->with('pedido', $pedido);
        } else {
            return redirect()->action('PedidoController@index');
        }
    }

    /*
     * Edita Pedido
     */
    public function update(Request $request, $id)
    {
        $pedido = Pedido::find($id);

        $pedido->cliente = $request->cliente;
        $pedido->produto = $request->produto;
        $pedido->status = $request->status;

        $pedido->save();

        return redirect()->action('PedidoController@index');
    }

    /*
     * Deleta Pedido
     */
    public function destroy($id)
    {
        $pedido = Pedido::where('id', $id)->get();

        if(!empty($pedido)){
            DB::delete("DELETE FROM pedidos WHERE id = ?", [$id]);
        }

        return redirect()->action('PedidoController@index');
    }

    /*
     * Faz Leitura dos Pedidos
     */
    private function setName($id)
    {
        $pedidoSlug = str_slug($id);

        $pedidos = DB::select("SELECT * FROM pedidos");
        $pedido = Pedido::all();

        $p = 0;
        foreach ($pedidos as $pedido) {
            if (str_slug($pedido->id) === $pedidoSlug) {
                $p++;
            }
        }

        if ($p > 0) {
            $pedidoSlug = $pedidoSlug . '-' . $p;
        }

        return $pedidoSlug;
    }
}
