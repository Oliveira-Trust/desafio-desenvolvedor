<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <h1>Formulário de Edição :: Pedido</h1>

        <?php
        $pedido = $pedido[0];
        ?>

        <form action="<?= url('/pedido/update', ['id' => $pedido->id]); ?>" method="post">

            <?= csrf_field(); ?>
            <?= method_field('PUT'); ?>

            <div class="form-group">
                <label for="cliente">Cliente</label>
                <input type="text" name="cliente" id="cliente" value="<?= $pedido->cliente; ?>" class="form-control">
            </div>

            <div class="form-group">
                <label for="produto">Produto</label>
                <input type="text" name="produto" id="produto" value="<?= $pedido->produto; ?>" class="form-control">
            </div>

            <div class="form-group">
                <label>Status</label>
                <select name="status" class="form-control" required>
                    <option selected disabled value="">Selecione o Status do Pedido:</option>
                    <option value="Em Aberto" <?= ($pedido->status == 'Em Aberto' ? 'selected="selected"' : ''); ?>>Em Aberto</option>
                    <option value="Pago" <?= ($pedido->status == 'Pago' ? 'selected="selected"' : ''); ?>>Pago</option>
                    <option value="Cancelado" <?= ($pedido->status == 'Cancelado' ? 'selected="selected"' : ''); ?>>Cancelado</option>
                </select>
            </div>

            <button type="submit" class="btn btn-danger" title="Atualizar Pedido">Atualizar Pedido</button>

        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Pedido.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>