<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <h1>Formulário de Cadastro :: Produto</h1>

        <form action="<?= url('/produto/store'); ?>" method="post">

            <?= csrf_field(); ?>

            <div class="form-group">
                <label for="title">Título do Produto</label>
                <input type="text" name="title" id="title" class="form-control">
            </div>

            <div class="form-group">
                <label for="description">Descrição do Produto</label>
                <textarea name="description" id="description" cols="30" rows="5" class="form-control"></textarea>
            </div>

            <div class="form-group">
                <label for="price">Valor do Produto (R$50.00)</label>
                <input type="text" name="price" id="price" class="form-control">
            </div>

            <button type="submit" class="btn btn-danger" title="Cadastrar Produto">Cadastrar Produto</button>

        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Produto.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>