<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login OliveiraTrust</title>

    <link rel="stylesheet" href="<?= asset('css/app.css'); ?>">
    <link rel="stylesheet" href="<?= asset('css/style.css'); ?>">
</head>
<body>
<div class="container my-5">
    <form class="form-signin" method="post" action="<?php echo e(route('admin.login.do')); ?>">
        <?php echo csrf_field(); ?>

        <img src="http://www.oliveiratrust.com.br/portal/img/logo.png" title="OliveiraTrust" alt="OliveiraTrust">

        <?php if($errors->all()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e($error); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <div class="form-group">
            <label for="email">E-mail:</label>
            <input type="text" name="email" id="email" class="form-control" value="rh@oliveiratrust.com.br" placeholder="Seu E-mail" required>
        </div>

        <div class="form-group">
            <label for="password">Senha:</label>
            <input type="password" name="password" id="password" class="form-control" value="123456" placeholder="Sua Senha" required>
        </div>

        <button type="submit" class="btn btn-danger btn-lg btn-block" title="Fazer Login">LOGIN</button>
    </form>
</div>

<script src="<?= asset('js/app.js'); ?>"></script>
</body>
</html>
