<?php $__env->startSection('content'); ?>
    <div class="container my-5">

        <h1>Pedido:</h1>

        <?php
        if(!empty($pedido)){

        foreach($pedido as $p){
        ?>
        <p><b>Cliente:</b> <?= $p->cliente; ?></p>

        <p><b>Produto:</b> <?= $p->produto; ?></p>

        <p><b>Status:</b> <?= $p->status; ?></p>

        <?php
        }
        }
        ?>

    </div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('Pedido.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>