<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <h1>Formulário de Edição :: Cliente</h1>

        <?php
        $cliente = $cliente[0];
        ?>

        <form action="<?= url('/cliente/update', ['id' => $cliente->id]); ?>" method="post">

            <?= csrf_field(); ?>
            <?= method_field('PUT'); ?>

            <div class="form-group">
                <label for="title">Nome do Cliente</label>
                <input type="text" name="title" id="title" value="<?= $cliente->title; ?>" class="form-control">
            </div>

            <div class="form-group">
                <label for="document">Documento do Cliente</label>
                <input type="text" name="document" id="document" value="<?= $cliente->document; ?>" class="form-control">
            </div>

            <div class="form-group">
                <label for="phone">Telefone do Cliente</label>
                <input type="text" name="phone" id="phone" value="<?= $cliente->phone; ?>" class="form-control">
            </div>

            <div class="form-group">
                <label for="address">Endereço do Cliente</label>
                <input type="text" name="address" id="address" value="<?= $cliente->address; ?>" class="form-control">
            </div>

            <button type="submit" class="btn btn-danger" title="Atualizar Cliente">Atualizar Cliente</button>

        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Cliente.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>