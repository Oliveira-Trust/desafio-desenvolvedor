<?php $__env->startSection('content'); ?>

    <div class="container my-5">
        <h1>Listagem de Clientes</h1>

        <?php

        if (!empty($clientes)) {

            echo "<table class='table table-striped table-hover'>";

            echo "<thead class='bg-danger text-white'>
                <td>Nome</td>
                <td>Documento</td>
                <td>Telefone</td>
                <td>Ações</td>
              </thead>";

            foreach ($clientes as $cliente) {

                $linkReadMore = url('/cliente/' . $cliente->name);
                $linkEditItem = url('/cliente/editar/' . $cliente->name);
                $linkRemoveItem = url('/cliente/remover/' . $cliente->name);

                echo "<tr>
                <td>{$cliente->title}</td>
                <td>{$cliente->document}</td>
                <td>{$cliente->phone}</td>
                <td><a href='{$linkReadMore}' class='text-danger' title='Ver Mais'>Ver Mais</a> | <a href='{$linkEditItem}' class='text-danger' title='Editar'>Editar</a> | <a href='{$linkRemoveItem}' class='text-danger' title='Excluir'>Excluir</a></td>
              </tr>";
            }

            echo "</table>";
        }
        ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Cliente.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>