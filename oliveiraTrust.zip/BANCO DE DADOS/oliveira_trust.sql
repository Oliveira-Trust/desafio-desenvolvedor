/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 100408
Source Host           : localhost:3306
Source Database       : oliveira_trust

Target Server Type    : MYSQL
Target Server Version : 100408
File Encoding         : 65001

Date: 2020-02-29 00:23:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for clientes
-- ----------------------------
DROP TABLE IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Id do Cliente',
  `title` varchar(255) DEFAULT NULL COMMENT 'Nome do Cliente',
  `name` varchar(255) DEFAULT '' COMMENT 'URL do Cliente',
  `document` text DEFAULT NULL COMMENT 'Documento do Cliente',
  `phone` varchar(255) DEFAULT '' COMMENT 'Telefone do Cliente',
  `address` varchar(255) DEFAULT '' COMMENT 'Endereço do Cliente',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of clientes
-- ----------------------------
INSERT INTO `clientes` VALUES ('1', 'Gabriel Pereira Bittencourt Passaes', 'gabriel-pereira-bittencourt-passaes', '123456789', '21966128509', 'Rua Alice Galvão, 33');

-- ----------------------------
-- Table structure for pedidos
-- ----------------------------
DROP TABLE IF EXISTS `pedidos`;
CREATE TABLE `pedidos` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Id do Pedido',
  `cliente` varchar(255) DEFAULT NULL COMMENT 'Cliente do Pedido',
  `produto` varchar(255) DEFAULT NULL COMMENT 'Produto do Pedido',
  `status` varchar(255) DEFAULT '' COMMENT 'Status do Pedido',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of pedidos
-- ----------------------------
INSERT INTO `pedidos` VALUES ('1', 'Gabriel Pereira Bittencourt Passaes', 'Camisa do Barcelona', 'Em Aberto');

-- ----------------------------
-- Table structure for produtos
-- ----------------------------
DROP TABLE IF EXISTS `produtos`;
CREATE TABLE `produtos` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Id do Produto',
  `image` varchar(255) DEFAULT NULL COMMENT 'Imagem do Produto',
  `title` varchar(255) DEFAULT NULL COMMENT 'Título do Produto',
  `name` varchar(255) DEFAULT '' COMMENT 'URL do Produto',
  `description` text DEFAULT NULL COMMENT 'Descrição do Produto',
  `price` decimal(10,2) DEFAULT NULL COMMENT 'Preço do Produto',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Data de Criação do Produto',
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp() COMMENT 'Data de Atualização do Produto',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of produtos
-- ----------------------------
INSERT INTO `produtos` VALUES ('1', null, 'Camisa do Barcelona', 'camisa-do-barcelona', 'Excelente material, ideal pra prática esportiva.', '200.00', null, null);

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Id do Usuário',
  `name` varchar(255) DEFAULT NULL COMMENT 'Nome do Usuário',
  `email` varchar(255) DEFAULT NULL COMMENT 'Email do Usuário',
  `email_verified_at` varchar(255) DEFAULT NULL COMMENT 'Verificação do Email do Usuário',
  `password` varchar(255) DEFAULT NULL COMMENT 'Senha do Usuário',
  `remember_token` varchar(255) DEFAULT NULL COMMENT 'Token do Usuário',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Data de Criação do Usuário',
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp() COMMENT 'Data de Atualização do Usuário',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('1', 'rh@oliveiratrust.com.br', 'rh@oliveiratrust.com.br', null, '$2y$10$sVmzRljmIAgVFSCNeyzsv.Yalap4JjmfumuL5E5.C4erGMK4Xy7fq', 'iweJhkPAkUr1RAHibLF1Y0Zai5lcobNJJbj8QrH8mxdJvWqa4xNc9kUTLAkU', '2020-02-29 03:16:44', '2020-02-29 00:16:59');
