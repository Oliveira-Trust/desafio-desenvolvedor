@extends('Pedido.master')

@section('content')
    <div class="container my-5">

        <h1>Pedido:</h1>

        <?php
        if(!empty($pedido)){

        foreach($pedido as $p){
        ?>
        <p><b>Cliente:</b> <?= $p->cliente; ?></p>

        <p><b>Produto:</b> <?= $p->produto; ?></p>

        <p><b>Status:</b> <?= $p->status; ?></p>

        <?php
        }
        }
        ?>

    </div>
@endsection




