@extends('Pedido.master')

@section('content')

    <div class="container my-5">
        <h1>Listagem de Pedidos</h1>

        <?php

        if (!empty($pedidos)) {

            echo "<table class='table table-striped table-hover'>";

            echo "<thead class='bg-danger text-white'>
                <td>Cliente</td>
                <td>Produto</td>
                <td>Status</td>
                <td>Ações</td>
              </thead>";

            foreach ($pedidos as $pedido) {

                $linkReadMore = url('/pedido/' . $pedido->id);
                $linkEditItem = url('/pedido/editar/' . $pedido->id);
                $linkRemoveItem = url('/pedido/remover/' . $pedido->id);

                echo "<tr>
                <td>{$pedido->cliente}</td>
                <td>{$pedido->produto}</td>
                <td>{$pedido->status}</td>
                <td><a href='{$linkReadMore}' class='text-danger' title='Ver Mais'>Ver Mais</a> | <a href='{$linkEditItem}' class='text-danger' title='Editar'>Editar</a> | <a href='{$linkRemoveItem}' class='text-danger' title='Excluir'>Excluir</a></td>
              </tr>";
            }

            echo "</table>";
        }
        ?>
    </div>

@endsection
