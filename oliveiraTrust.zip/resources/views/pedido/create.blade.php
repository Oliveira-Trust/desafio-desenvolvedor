@extends('Pedido.master')

@section('content')
    <div class="container my-5">
        <h1>Formulário de Cadastro :: Pedido</h1>

        <form action="<?= url('/pedido/store'); ?>" method="post">

            <?= csrf_field(); ?>

            <div class="form-group">
                <label for="cliente">Cliente</label>
                <input type="text" name="cliente" id="cliente" class="form-control">
            </div>

            <div class="form-group">
                <label for="produto">Produto</label>
                <input type="text" name="produto" id="produto" class="form-control">
            </div>

            <div class="form-group">
                <label>Status</label>
                <select name="status" class="form-control" required>
                    <option selected disabled value="">Selecione o Status do Pedido:</option>
                    <option value="Em Aberto">Em Aberto</option>
                    <option value="Pago">Pago</option>
                    <option value="Cancelado">Cancelado</option>
                </select>
            </div>

            <button type="submit" class="btn btn-danger" title="Cadastrar Pedido">Cadastrar Pedido</button>

        </form>
    </div>
@endsection
