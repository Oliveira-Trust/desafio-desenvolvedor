@extends('Cliente.master')

@section('content')
    <div class="container my-5">

        <h1>Cliente:</h1>

        <?php
        if(!empty($clientes)){

        foreach($clientes as $cliente){
        ?>
        <div class="my-4">
            <p><b>Cliente:</b> <?= $cliente->title; ?></p>

            <p><b>Documento:</b> <?= $cliente->document; ?></p>

            <p><b>Telefone:</b> <?= $cliente->phone; ?></p>

            <p><b>Endereço:</b> <?= $cliente->address; ?></p>
        </div>

        <?php
        }
        }
        ?>

    </div>
@endsection




