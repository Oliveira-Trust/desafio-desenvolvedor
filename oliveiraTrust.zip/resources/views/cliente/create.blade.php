@extends('Cliente.master')

@section('content')
    <div class="container my-5">
        <h1>Formulário de Cadastro :: Cliente</h1>

        <form action="<?= url('/cliente/store'); ?>" method="post">

            <?= csrf_field(); ?>

            <div class="form-group">
                <label for="title">Nome do Cliente</label>
                <input type="text" name="title" id="title" class="form-control">
            </div>

            <div class="form-group">
                <label for="document">Documento do Cliente</label>
                <input type="text" name="document" id="document" class="form-control">
            </div>

            <div class="form-group">
                <label for="phone">Telefone do Cliente</label>
                <input type="text" name="phone" id="phone" class="form-control">
            </div>

            <div class="form-group">
                <label for="address">Endereço do Cliente</label>
                <input type="text" name="address" id="address" class="form-control">
            </div>

            <button type="submit" class="btn btn-danger" title="Cadastrar Cliente">Cadastrar Cliente</button>

        </form>
    </div>
@endsection
