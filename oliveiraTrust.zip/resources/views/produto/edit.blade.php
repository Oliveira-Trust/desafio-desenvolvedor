@extends('Produto.master')

@section('content')
    <div class="container my-5">
        <h1>Formulário de Edição :: Produto</h1>

        <?php
        $produto = $produto[0];
        ?>

        <form action="<?= url('/produto/update', ['id' => $produto->id]); ?>" method="post">

            <?= csrf_field(); ?>
            <?= method_field('PUT'); ?>

            <div class="form-group">
                <label for="title">Título do Produto</label>
                <input type="text" name="title" id="title" value="<?= $produto->title; ?>" class="form-control">
            </div>

            <div class="form-group">
                <label for="description">Descrição do Produto</label>
                <textarea name="description" id="description" cols="30" rows="10" class="form-control"><?= $produto->description; ?></textarea>
            </div>

            <div class="form-group">
                <label for="price">Valor do Produto</label>
                <input type="text" name="price" id="price" value="<?= $produto->price; ?>" class="form-control">
            </div>

            <button type="submit" class="btn btn-danger" title="Atualizar Produto">Atualizar Produto</button>

        </form>
    </div>
@endsection
