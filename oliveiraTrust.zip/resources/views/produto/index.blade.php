@extends('Produto.master')

@section('content')

    <div class="container my-5">
        <h1>Listagem de Produtos</h1>

        <?php

        if (!empty($produtos)) {

            echo "<table class='table table-striped table-hover'>";

            echo "<thead class='bg-danger text-white'>
                <td>Título</td>
                <td>Preço</td>
                <td>Ações</td>
              </thead>";

            foreach ($produtos as $produto) {

                $linkReadMore = url('/produto/' . $produto->name);
                $linkEditItem = url('/produto/editar/' . $produto->name);
                $linkRemoveItem = url('/produto/remover/' . $produto->name);

                echo "<tr>
                <td>{$produto->title}</td>
                <td>R$" . number_format($produto->price, 2, ',', '.') . "</td>
                <td><a href='{$linkReadMore}' class='text-danger' title='Ver Mais'>Ver Mais</a> | <a href='{$linkEditItem}' class='text-danger' title='Editar'>Editar</a> | <a href='{$linkRemoveItem}' class='text-danger' title='Excluir'>Excluir</a></td>
              </tr>";
            }

            echo "</table>";
        }
        ?>
    </div>

@endsection
