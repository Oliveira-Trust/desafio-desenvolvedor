@extends('Produto.master')

@section('content')
    <div class="container my-5">

        <h1>Produto:</h1>

        <?php
        if(!empty($produto)){

        foreach($produto as $pdt){
        ?>
        <div class="my-4">
            <p><b>Nome do Produto:</b> <?= $pdt->title; ?></p>

            <p><b>Descrição:</b> <?= $pdt->description; ?></p>

            <p><b>Valor:</b> R$<?= number_format($pdt->price, 2, ',', '.'); ?></p>
        </div>
        <?php
        }
        }
        ?>

    </div>
@endsection




